import { defaultTheme, defineUserConfig } from 'vuepress';
import { searchPlugin } from "@vuepress/plugin-search";
import { backToTopPlugin } from '@vuepress/plugin-back-to-top';
import { mdEnhancePlugin } from "vuepress-plugin-md-enhance";
import { copyCodePlugin } from "vuepress-plugin-copy-code2";

export default defineUserConfig({
    title: 'vuepress模板',
    description: 'vuepress模板',
    plugins: [
        // 查询插件
        searchPlugin({
            maxSuggestions: 20
        }),
        // 回到顶部插件
        backToTopPlugin(),
        // 美化主题插件
        mdEnhancePlugin({
            codetabs: true,
            mark: true
        }),
        // 复制代码插件
        copyCodePlugin({})
    ],
    theme: defaultTheme({
        navbar: [
            '/',
            '/subs/',
        ],
        sidebar: {
            '/': ['/'],
            '/subs/': [
                '/subs/', 
                '/subs/page1/', 
            ],
        },
    })
});